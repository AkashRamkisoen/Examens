

<?php $__env->startSection('content'); ?>

    <h1 class="mt-5">Products</h1>

    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <nav class="nav">
        <ul class="nav nav-tabs">
            <li class="nav-item">
                <a class="nav-link" href="<?php echo e(route('products.index')); ?>">Index</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="<?php echo e(route('products.create')); ?>">Create</a>
            </li>
            <li class="nav-item">
                <a class="nav-link active" href="<?php echo e(route('products.edit',
                                        ['product' => $product->id])); ?>">Edit Product</a>
            </li>
        </ul>
    </nav>
    
    <form method="POST" action="/products/<?php echo e($product->id); ?>">
        <?php echo method_field('PUT'); ?>         
        <?php echo csrf_field(); ?>

        <div class="form-group">
            <label for="productname">Productname</label>
            <input type="text" name="productname" class="form-control" id="productname"
                aria-describedly="productnameHelp" value="<?php echo e($product->productname); ?>">
        </div>
    
        <div class="form-group">
            <label for="description">Description</label>
            <textarea class="form-control" name="description" id="description" rows="3">
                <?php echo e($product->description); ?></textarea>
        </div>

        <div class="form-group">
            <label for="productname">Price</label>
            <input type="text" name="price" class="form-control" id="price"
                aria-describedly="priceHelp" value="<?php echo e($product->price); ?>">
        </div>
    
        <button type="submit" class="btn btn-primary">Update</button>

    </form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\laravel60\resources\views/products/edit.blade.php ENDPATH**/ ?>
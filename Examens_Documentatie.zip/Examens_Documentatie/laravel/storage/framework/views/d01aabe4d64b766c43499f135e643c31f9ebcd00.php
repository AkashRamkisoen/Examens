

<?php $__env->startSection('content'); ?>
    <h1 class="mt-5">Error</h1>

        <div class="alert alert-danger">
            <?php echo e($exception->getMessage()); ?>

        </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\laravel60\resources\views/errors/403.blade.php ENDPATH**/ ?>
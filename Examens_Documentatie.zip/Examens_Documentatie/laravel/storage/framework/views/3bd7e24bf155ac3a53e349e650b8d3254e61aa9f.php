

<?php $__env->startSection('content'); ?>

<h1 class="mt-5">Products</h1>

<nav class="nav">
        <ul class="nav nav-tabs">
            <li class="nav-item">
                <a class="nav-link" href="<?php echo e(route('products.index')); ?>">Index</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="<?php echo e(route('products.create')); ?>">Create</a>
            </li>
            <li class="nav-item">
                <a class="nav-link active" href="<?php echo e(route('products.show',
                                        ['product' => $product->id])); ?>">Product Details</a>
            </li>
        </ul>
    </nav>

    <div class="card">
        <div class="card-header">
            Product Details
        </div>
        <div class="card-body">
            <h2 class="card-title"><?php echo e($product->productname); ?></h2>
            <p class="card-text"><?php echo e($product->description); ?></p>
            <p class="card-text">Price: <?php echo e($product->price); ?></p>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\laravel60\resources\views/products/show.blade.php ENDPATH**/ ?>
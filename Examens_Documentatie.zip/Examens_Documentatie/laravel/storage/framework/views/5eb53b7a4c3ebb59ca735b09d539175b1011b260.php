

<?php $__env->startSection('content'); ?>

    <h1 class="mt-5">Products</h1>

    <?php if(session('message')): ?>
        <div class="alert alert-success">
            <?php echo e(session('message')); ?>

        </div>
    <?php endif; ?>


    <nav class="nav">
        <ul class="nav nav-tabs">
            <li class="nav-item">
                <a class="nav-link active" href="<?php echo e(route('products.index')); ?>">Index</a>
            </li>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create products')): ?>
            <li class="nav-item">
                <a class="nav-link" href="<?php echo e(route('products.create')); ?>">Create</a>
            </li>
            <?php endif; ?>
        </ul>
    </nav>

    <table class="table . table-striped">
        <thead>
        <tr>
            <th scope="col">#</th>
            <th scope="col">Productname</th>
            <th scope="col">Price</th>
            <th scope="col">Product details</th>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit products')): ?>
            <th scope="col">Edit</th>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete products')): ?>
            <th scope="col">Delete</th>
            <?php endif; ?>
        </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td scope="row"><?php echo e($product->id); ?></td>
                <td><?php echo e($product->productname); ?></td>
                <td><?php echo e($product->price); ?></td>
                <td><a href="<?php echo e(route('products.show',
                    ['product' => $product->id])); ?>">Details</a>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit products')): ?>    
                <td><a href="<?php echo e(route('products.edit', 
                    ['product' => $product->id])); ?>">Edit product</a></td>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete products')): ?>    
                <td><a href="<?php echo e(route('products.delete', 
                    ['product' => $product->id])); ?>">Delete</a></td>    
                <?php endif; ?> 
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\laravel60\resources\views/products/index.blade.php ENDPATH**/ ?>